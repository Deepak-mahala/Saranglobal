
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>JVDN International (OPC) PVT.LTD.</title>
    <meta name="description" content="JVDN International (OPC) PVT.LTD.">
    <meta name="author" content="JVDN International (OPC) PVT.LTD.">
    <link rel="shortcut icon" href="assets/img/logo/ficon.png" type="image/x-icon">
    <!-- Mobile Specific Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <!-- <link rel="stylesheet" href="assets/css/video.min.css"> -->
    <!-- <link rel="stylesheet" href="assets/css/jquery.mCustomScrollbar.min.css"> -->
    <link rel="stylesheet" href="assets/css/slick.css">
    <link rel="stylesheet" href="assets/css/rs6.css">
    <link rel="stylesheet" href="assets/css/slick-theme.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css" rel="stylesheet">
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.0.0/css/all.css">

    
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-REN0WZZ0B9"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-REN0WZZ0B9');
</script>

</head>
<body>
    
    <div class="up">
        <a href="#" class="scrollup text-center"><i class="fas fa-chevron-up"></i></a>
    </div>
    <!-- Start of header section
    ============================================= -->
    <header id="ft-header" class="ft-header-section header-style-two">
        <div class="ft-header-top">
            <div class="container">
                <div class="ft-header-top-content d-flex justify-content-between align-items-center">
                    <div class="ft-header-top-cta ul-li">
                        <ul>
                            
                            <li><i class="fal fa-envelope"></i><a href="mailto:jayesh@jvdninternational.com">jayesh@jvdninternational.com</a></li>
                            <li><i class="fab fa-whatsapp"></i><a href="https://api.whatsapp.com/send?phone=+91 91361 87951" target="_blank">+91 91361 87951</a></li>
                        </ul>
                    </div>
                    <div class="ft-header-cta-info d-flex">
                        <div class="ft-header-cta-icon d-flex justify-content-center align-items-center">
                            <i class="flaticon-call"></i>
                        </div>
                        <div class="ft-header-cta-text headline pera-content">
                            <p>Get In Touch</p>
                            <h3><a href="tel:+91 91361 87951">+91 91361 87951</a></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="ft-header-main-menu-wrapper">
            <div class="container">
                <div class="ft-header-main-menu-area position-relative">
                    <div class="ft-header-main-menu d-flex align-items-center justify-content-between position-relative">
                        <div class="ft-site-logo-area">
                            <div class="ft-site-logo position-relative">
                                <a href="index.html"><img src="assets/img/logo/logo.png" alt=""></a>
                            </div>
                        </div>
                        <div class="ft-main-navigation-area">
                            <nav class="ft-main-navigation clearfix ul-li">
                                <ul id="ft-main-nav" class="nav navbar-nav clearfix">
                                    <li><a href="index.html">Home</a></li>
                                    <li><a href="about.html">About</a></li>
                                    <li><a href="team.html">Team</a></li>
                                    <li><a href="product.html">Products</a></li>
                                    <li class="active"><a href="supplier.html">Suppliers</a></li>
                                    <li><a href="affiliations.html">Affiliations</a></li>
                                    <li><a href="contact.html">Contact</a></li>
                                </ul>
                            </nav>
                        </div>
                        <div class="ft-header-cta-btn">
                            <div id="google_translate_element"></div>
                        </div>
                    </div>
                    <div class="mobile_menu position-relative">
                        <div class="mobile_menu_button open_mobile_menu">
                            <i class="fal fa-bars"></i>
                        </div>
                        <div class="mobile_menu_wrap">
                            <div class="mobile_menu_overlay open_mobile_menu"></div>
                            <div class="mobile_menu_content">
                                <div class="mobile_menu_close open_mobile_menu">
                                    <i class="fal fa-times"></i>
                                </div>
                                <div class="m-brand-logo">
                                    <a href="index.html"><img src="assets/img/logo/logo.png" alt=""></a>
                                </div>
                                <nav class="mobile-main-navigation  clearfix ul-li">
                                    <ul id="m-main-nav" class="navbar-nav text-capitalize clearfix">
                                        <li><a href="index.html">Home</a></li>
                                        <li><a href="about.html">About</a></li>
                                        <li><a href="team.html">Team</a></li>
                                        <li><a href="product.html">Products</a></li>
                                        <li class="active"><a href="supplier.html">Suppliers</a></li>
                                        <li><a href="affiliations.html">Affiliations</a></li>
                                        <li><a href="contact.html">Contact</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <!-- /Mobile-Menu -->
                    </div>
                </div>
            </div>
        </div>
    </header>
<!-- End of header section
    ============================================= -->

<!-- Start of Breadcrumb section
    ============================================= -->
    <section id="ft-breadcrumb" class="ft-breadcrumb-section position-relative" data-background="assets/img/bg/bread-bg.jpg">
        <span class="background_overlay"></span>
        <span class="design-shape position-absolute"><img src="assets/img/shape/tmd-sh.png" alt=""></span>
        <div class="container">
            <div class="ft-breadcrumb-content headline text-center position-relative">
                <h2>Suppliers</h2>
                <div class="ft-breadcrumb-list ul-li">
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li>Suppliers</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>  
<!-- End of Breadcrumb section
    ============================================= -->

<!-- Start of Project details  section
    ============================================= -->
    <section id="ft-project-details" class="ft-project-details-section page-padding">
        <div class="container">
            <div class="ft-project-overview">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="ft-project-details-img">
                            <img src="assets/img/supplier/prd.jpg" alt="">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="ft-project-overview-text-wrapper headline pera-content">
                            <h3>Suppliers</h3>
                            <div class="ft-project-overview-comment-list">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="ft-project-overview-list-item ul-li-block">
                                            <ul>
                                                <li>If you are a manufacturer of export quality products, and find it difficult to market your products abroad, we can help you achieve your goal, by being your representative in the countries, we export to.</li>
                                                <li>While, we can help you to export to any country around the globe, we have excellent network of importers in over 20 countries in the African Market.</li>
                                                <li>Just fill in the form below & we will help you grow your business internationally. The more details you provide us the more-easy it will be for us to represent you.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <p>Come join the band wagon of the top exporters, with us. Make JVDN INTERNATIONAL (OPC) PRIVATE LIMITED, your export manager.</p><br>
                        </div>
                    </div>
                </div>
            </div>
            <div class="ft-project-overview-text-wrapper headline pera-content">
                <h3>Supplier Information Form (Private & Confidential)</h3>
                <p>Guidelines to fill the information: To be filled by all prospective supplier to AGPL, All details would be kept strictly confidential</p>
                <div class="ft-contact-page-form-wrapper headline">
                    <form action="sendmail.php" method="post">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <input type="text" name="first_name" placeholder="Your Name" required>
                                    </div>
                                    <div class="col-lg-12">
                                        <input type="email" name="email" placeholder="Your Email" required>
                                    </div>
                                    <div class="col-lg-12">
                                        <input type="text" name="telephone" placeholder="Number" required>
                                    </div>
                                    <div class="col-lg-12">
                                        <textarea name="comments" placeholder="Your Message"></textarea>
                                    </div>
                                    <div class="col-lg-12">
                                        <input type="submit" name="submit" class="submit">
                                    </div>
                                </div>
                        </form>
                </div>
            </div>
        </div>
    </section>
<!-- End of Project details section
    ============================================= -->
        

<div class="float-sm">
  <div class="fl-fl float-fb">
    <i class="fab fa-facebook"></i>
    <a href="https://www.facebook.com/jvdninternationalpvtltd/" target="_blank"> Like us!</a>
  </div>
  <div class="fl-fl float-tw">
    <i class="fab fa-instagram"></i>
    <a href="https://www.instagram.com/jvdninternationalpvtld/" target="_blank">Follow us!</a>
  </div>
  <div class="fl-fl float-gp">
    <i class="fab fa-linkedin"></i>
    <a href="https://www.linkedin.com/in/jvdninternationalpvtltd/" target="_blank">Recommend us!</a>
  </div>
  <div class="fl-fl float-rs">
    <i class="fab fa-twitter"></i>
    <a href="https://twitter.com/jvdninternatio1" target="_blank">Follow via RSS</a>
  </div>
  <div class="fl-fl float-ig">
    <i class="fab fa-whatsapp"></i>
    <a href="https://api.whatsapp.com/send?phone=+91 91361 87951" target="_blank">Whatsapp Now!</a>
  </div>
</div>


<div class="floating_btn2">
      <a target="_blank" onclick="openForm()">
        <div class="contact_icon2">
          <i class="fa fa-file my-float2"></i>
        </div>
        <div class="form-popup" id="myForm">
                        <form method="post" enctype="multipart/form-data">
                            <div class="row clearfix">
                                <div class="form-group col-lg-12 col-md-12 col-xs-12">
                                    <div class="field-label">Name of the Company <sup>*</sup></div>
                                    <input type="text" name="company_name" placeholder="" value="" required>
                                </div>
                                
                                <div class="form-group col-lg-12 col-md-12 col-xs-12">
                                    <div class="field-label">Regd. Office address <sup>*</sup></div>
                                    <textarea name="address" name="regofficeaddress" placeholder=""></textarea>
                                </div>
                                
                                <div class="form-group col-lg-6 col-md-6 col-xs-12">
                                    <div class="field-label">Pin Code <sup>*</sup></div>
                                    <input type="tel" name="pincode" value="" placeholder="" required>
                                </div>
                                
                                <div class="form-group col-lg-6 col-md-6 col-xs-12">
                                    <div class="field-label">Landline No. <sup>*</sup></div>
                                    <input type="tel" name="landline" value="" placeholder="">
                                </div>

                                <div class="form-group col-lg-6 col-md-6 col-xs-12">
                                    <div class="field-label">Mobile No. <sup>*</sup></div>
                                    <input type="tel" name="phone" value="" placeholder="" required>
                                </div>
                                
                                <div class="form-group col-lg-6 col-md-6 col-xs-12">
                                    <div class="field-label">Email Address <sup>*</sup></div>
                                    <input type="email" name="email" value="" placeholder="">
                                </div>

                                 <div class="form-group col-lg-6 col-md-6 col-xs-12">
                                    <div class="field-label">Website <sup>*</sup></div>
                                    <input type="text" name="website" value="" placeholder="">
                                </div>

                                <div class="form-group col-lg-12">
                                    <div class="field-label">Names of Directors / Owners <sup>*</sup></div>
                                </div>
                                    <div class="form-group col-lg-4">
                                        <div class="field-label">Name</div>
                                        <input type="text" name="name" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <div class="field-label">Designation</div>
                                        <input type="text" name="designation" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <div class="field-label">Mobile number</div>
                                        <input type="tel" name="mobile" value="" placeholder="">
                                    </div>
                                   
                                   <div class="form-group col-lg-4">
                                        <input type="text" name="name1" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <input type="text" name="name2" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <input type="text" name="designation1" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <input type="text" name="designation2" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <input type="tel" name="mobile1" value="" placeholder="">
                                    </div>
                                   <div class="form-group col-lg-4">
                                        <input type="tel" name="mobile2" value="" placeholder="">
                                    </div>

                                <div class="form-group col-lg-12 col-md-12 col-xs-12">
                                    <div class="field-label">Address of Factory/ies <sup>*</sup></div>
                                    <textarea name="own_address" name="factoryaddress" placeholder=""></textarea>
                                </div>

                                <div class="form-group col-lg-6 col-md-6 col-xs-12">
                                    <div class="field-label">Pin Code <sup>*</sup></div>
                                    <input type="tel" name="own_pincode" value="" placeholder="" required>
                                </div>
                                
                                <div class="form-group col-lg-6 col-md-6 col-xs-12">
                                    <div class="field-label">Landline No. <sup>*</sup></div>
                                    <input type="tel" name="own_landline" value="" placeholder="">
                                </div>

                                <div class="form-group col-lg-12 col-md-12 col-xs-12">
                                    <div class="field-label">Date Company was Established</div>
                                    <input type="date" name="date" value="" placeholder="">
                                </div>

                                <div class="form-group col-lg-12">
                                    <div class="field-label">Gross annual sales for the last three years (exports only) </div>
                                </div>
                                <div class="form-group col-lg-6">
                                    <div class="field-label">First Year</div>
                                    <input type="text" name="f_year" value="" placeholder="">
                                </div>
                                <div class="form-group col-lg-6">
                                    <div class="field-label">(In Crores)</div>
                                    <input type="text" name="f_caror" value="" placeholder="">
                                </div>
                                <div class="form-group col-lg-6">
                                    <div class="field-label">Secound Year</div>
                                    <input type="text" name="s_year" value="" placeholder="">
                                </div>
                                <div class="form-group col-lg-6">
                                    <div class="field-label">(In Crores)</div>
                                    <input type="text" name="s_caror" value="" placeholder="">
                                </div>
                                <div class="form-group col-lg-6">
                                    <div class="field-label">Third Year</div>
                                    <input type="text" name="t_year" value="" placeholder="">
                                </div>
                                <div class="form-group col-lg-6">
                                    <div class="field-label">(In Crores)</div>
                                    <input type="text" name="t_caror" value="" placeholder="">
                                </div>
                                
                                <div class="form-group col-lg-6 col-md-6 col-xs-12">
                                    <div class="field-label" name="structure" value="">Company Structure (Check One)</div>
                                    <select>
                                        <option>Select</option>
                                        <option value="Government">Government</option>
                                        <option value="Public limited">Public limited</option>
                                        <option value="Private Limited">Private Limited</option>
                                        <option value="Association">Association</option>
                                        <option value="Partnership">Partnership</option>
                                        <option value="proprietorship">proprietorship</option>
                                        <option value="Joint venture">Joint venture</option>
                                        <option value="Franchise">Franchise</option>
                                        <option value="Non - profit">Non - profit</option>
                                    </select>
                                </div>

                                <div class="form-group col-lg-12">
                                    <div class="field-label">Contact details with mobile number </div>
                                </div>
                                <div class="form-group col-lg-4">
                                        <div class="field-label">Main Contact</div>
                                        <input type="tel" name="main_phone" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <div class="field-label">Marketing</div>
                                        <input type="tel" name="marketing_phone" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <div class="field-label">Accounts</div>
                                        <input type="tel" name="date" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <div class="field-label">Sales</div>
                                        <input type="tel" name="sales_phone" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <div class="field-label">Logistics</div>
                                        <input type="tel" name="logistics_phone" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <div class="field-label">Factory</div>
                                        <input type="tel" name="factory_phone" value="" placeholder="">
                                    </div>

                                    <div class="form-group col-lg-6 col-md-6 col-xs-12">
                                    <div class="field-label" name="type_business" value="">Type of Business / Commodity service (check one)</div>
                                    <select>
                                        <option>Select</option>
                                        <option value="Manufacturer">Manufacturer</option>
                                        <option value="Wholesaler">Wholesaler</option>
                                        <option value="Distributor">Distributor</option>
                                        <option value="Trader">Trader</option>
                                        <option value="Licensed seller">Licensed seller</option>
                                        <option value="Service provider">Service provider</option>
                                        <option value="Distribtuion">Distribtuion</option>
                                        <option value="Freight / Transportation">Freight / Transportation</option>
                                        <option>Non of these</option>
                                    </select>
                                </div>
                                <div class="form-group col-lg-6">
                                        <div class="field-label">Others</div>
                                        <input type="text" name="others" value="" placeholder="">
                                </div>

                                <div class="form-group col-lg-12 col-md-12 col-xs-12">
                                    <div class="field-label">List goods manufactured /supplied <sup>*</sup></div>
                                    <textarea name="list_supplied" name="regofficeaddress" placeholder=""></textarea>
                                </div>
                                <div class="form-group col-lg-12 col-md-12 col-xs-12">
                                    <div class="field-label">Brand name/s under which you manufacture <sup>*</sup></div>
                                    <textarea name="brand_name" name="regofficeaddress" placeholder=""></textarea>
                                </div>

                                <div class="form-group col-lg-6 col-md-6 col-xs-12">
                                    <div class="field-label" name="buyers_brand" value="">Do you manufacture, with buyers’ brand name <sup>*</sup></div>
                                    <select>
                                        <option>Select</option>
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>
                                    </select>
                                </div>

                                <div class="form-group col-lg-12">
                                    <div class="field-label">Production/Manufacturing Capacity (Per Month) </div>
                                </div>
                                    <div class="form-group col-lg-6">
                                    <div class="field-label">Product</div>
                                        <input type="text" name="product" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <div class="field-label">Quantity</div>
                                        <input type="text" name="quantity" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <input type="text" name="product1" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <input type="text" name="product2" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <input type="text" name="quantity1" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <input type="text" name="quantity2" value="" placeholder="">
                                    </div>

                                    <div class="form-group col-lg-12">
                                    <div class="field-label">List of Registrations </div>
                                </div>
                                    <div class="form-group col-lg-4">
                                    <div class="field-label">IEC code no</div>
                                        <input type="tel" name="iec_code" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <div class="field-label">GST No</div>
                                        <input type="tel" name="gst_no" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <div class="field-label">PAN No</div>
                                        <input type="tel" name="pan_no" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <div class="field-label">TAN No</div>
                                        <input type="tel" name="ten_no" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <div class="field-label">CIN/LLP No</div>
                                        <input type="tel" name="cin_no" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <div class="field-label">FIEO No</div>
                                        <input type="tel" name="fieo_no" value="" placeholder="">
                                    </div>
                                     <div class="form-group col-lg-6">
                                        <div class="field-label">MSME No</div>
                                        <input type="tel" name="msme_no" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <div class="field-label">RCMC No</div>
                                        <input type="tel" name="rcmc_no" value=""placeholder="">
                                    </div>

                                    <div class="form-group col-lg-6 col-md-6 col-xs-12">
                                    <div class="field-label" name="geo_cervice" value="">Geographic Service Areas (Check One)</div>
                                    <select>
                                        <option>Select</option>
                                        <option value="Local">Local</option>
                                        <option value="Regional">Regional</option>
                                        <option value="National">National</option>
                                        <option value="International">International</option>
                                    </select>
                                    </div>

                                    <div class="form-group col-lg-12">
                                        <div class="field-label">Which all export promotion councils you are regd. with</div>
                                        <input type="text" name="export" value="" placeholder="">
                                    </div>

                                    <div class="form-group col-lg-12">
                                        <div class="field-label">Nearest port for Embarkment</div>
                                        <input type="text" name="nearest_port" value="" placeholder="">
                                    </div>

                                    <div class="form-group col-lg-12">
                                        <div class="field-label">Have you previously done business with Adijina Global Private Limited or its Associates, if Yes, When & whom <sup>*</sup></div>
                                        <input type="text" name="previously" value="" placeholder="">
                                    </div>

                                    <div class="form-group col-lg-12">
                                        <div class="field-label">Bankers Information</div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <div class="field-label">Bank Name</div>
                                        <input type="text" name="bank_name" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <div class="field-label">Beneficiary Name</div>
                                        <input type="text" name="beneficiary_name" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-12">
                                        <div class="field-label">Bank Address</div>
                                        <textarea type="text" name="bank_address" placeholder=""></textarea>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <div class="field-label">Bank Account No</div>
                                        <input type="tel" name="account_no" value="" placeholder="">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <div class="field-label">IFSC Code</div>
                                        <input type="text" name="ifsc_code" value="" placeholder="">
                                    </div>

                                    <div class="form-group col-lg-12">
                                        <div class="field-label">Two Visiting Cards (PDF, JPG format only)</div>
                                        <input type="file" name="attachment" placeholder="">
                                    </div>

                                    <div class="form-group col-lg-12">
                                        <div class="field-label">Copy of all applicable statutory registration certificates (CIN, PAN, TAN, GST, IEC, MSME, etc) (PDF, JPG format only)</div>
                                        <input type="file" name="attachment" placeholder="">
                                    </div>

                                    <div class="form-group col-lg-12">
                                        <div class="field-label">Additional sheets (PDF, JPG format only)</div>
                                        <input type="file" name="attachment" placeholder="">
                                    </div>
                               
                                <div class="form-group text-left col-md-12 col-xs-12"><button type="submit" name="submit" class="theme-btn btn-style-three">SUBMIT</button></div>
                            </div>
                        
                        </form>
        </div>
      </a>
      <p class="text_icon2">Our Brochure</p>
    </div>


    
<!-- Start Of Footer section
    ============================================= -->
    <footer id="ft-footer-2" class="ft-footer-section-2" data-background="assets/img/bg/f-bg.png">
        <div class="ft-footer-widget-wrapper-2">
            <div class="container">
                <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <div class="ft-footer-widget">
                                <div class="ft-footer-newslatter-widget pera-content headline">
                                    <div class="ft-footer-info-widget ul-li ">
                                        <h3 class="widget-title">Official info:</h3>
                                        <ul>
                                            <li>
                                                <i class="fas fa-map-marker-alt"></i> 
                                                <a href="#">B1121-22, Sun Westbank, Ashram Rd, Vishalpur, Muslim Society, Navrangpura, Ahmedabad, Gujarat 380 009, India.</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="ft-footer-widget">
                                <div class="ft-footer-newslatter-widget pera-content headline">
                                    <div class="ft-footer-info-widget ul-li ">
                                        <h3 class="widget-title">Official info:</h3>
                                        <ul>
                                            <li>
                                                <i class="fas fa-phone"></i><a href="tel:+91 91361 87951">+91 91361 87951</a>
                                            </li><br>
                                            <li>
                                                <i class="fas fa-envelope"></i><a href="mailto:jayesh@jvdninternational.com">jayesh@jvdninternational.com</a>
                                            </li>
                                            <li>
                                                <i class="fas fa-globe"></i><a href="http://www.jvdninternational.com/" target="_blank">www.jvdninternational.com</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="ft-footer-widget">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3671.509563534357!2d72.56696751484988!3d23.041772921392546!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e846035c93e15%3A0xa27c7d970fb42fb0!2sAggarwal%20Center%2C%20Cu%20Shah%20Commerce%20College%2C%20Besides%20Kalupur%20Bank%2C%20Icome%20Tax%20Cross%20Roads%2C%20Ashram%20Rd%2C%20Sattar%20Taluka%20Society%2C%20Usmanpura%2C%20Ahmedabad%2C%20Gujarat%20380014!5e0!3m2!1sen!2sin!4v1641545521271!5m2!1sen!2sin" width="100%" height="150" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                            </div>
                        </div>
                </div>
            </div>
        </div>
        <div class="ft-footer-copywrite-1 text-center">
            <span><a href="index.html">Home </a> | <a href="about.html">About</a> | <a href="team.html">Team </a> | <a href="product.html">Product</a> | <a href="supplier.html">Supplier</a> | <a href="affiliations.html">Affiliation</a> | <a href="contact.html">Contact</a></span>
        </div>
        <div class="ft-footer-copywrite-2 text-center">
            <span>&copy; 2022 <a href="http://www.jvdninternational.com/" target="_blank">JVDN International (OPC) PVT.LTD.</a> | All Rights Reserved. Designed By: <a href="https://visionartinfotech.com/" target="_blank">Vision Art Infotech</a></span>
        </div>
    </footer>   
<!-- End of Footer section
    ============================================= -->
    
    <script type="text/javascript">
    function openForm() {
      document.getElementById("myForm").style.display = "block";
    }

    function closeForm() {
      document.getElementById("myForm").style.display = "none";
    }
    </script>
    <script type="text/javascript">
        function googleTranslateElementInit() {
          new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>

    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>    


    <!-- For Js Library -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- <script src="assets/js/popper.min.js"></script> -->
    <!-- <script src="assets/js/jquery.magnific-popup.min.js"></script> -->
    <!-- <script src="assets/js/appear.js"></script> -->
    <script src="assets/js/slick.js"></script>
    <!-- <script src="assets/js/jquery.counterup.min.js"></script> -->
    <!-- <script src="assets/js/jquery.cssslider.min.js"></script> -->
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/rs6.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>         